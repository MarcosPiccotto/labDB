/* 1.​ Calcular el rating promedio por país. Listar el país, rating promedio, y cantidad de
rating. Listar en orden descendente por rating promedio. Usar el campo
“review_scores.review_scores_rating” para calcular el rating promedio. */

db.listingsAndReviews.aggregate([
  {
    $group: {
      _id: "$address.country",
      avg_rating: { $avg: "$review_scores.review_scores_rating" },
      count_rating: { $sum: 1 }
    }
  },
  {
    $sort: { avg_rating: -1 }
  },
  {
    $project: {
      _id: 0,
      country: "$_id",
      avg_rating: 1,
      count_rating: 1
    }
  }
]);

/* 2.​ Listar los 20 alojamientos que tienen las reviews más recientes. Listar el id, nombre,
fecha de la última review, y cantidad de reviews del alojamiento. Listar en orden
descendente por cantidad de reviews.
HINT: $first pueden ser de utilidad. */
db.listingsAndReviews.aggregate([
  { $sort: { last_review: -1 } },
  { $limit: 20 },
  {
    $project: {
      _id: 1,
      name: 1,
      last_review: 1,
      number_of_reviews: 1
    }
  },
  { $sort: { number_of_reviews: -1 } }
]);

/* 3.​ Crear la vista “top10_most_common_amenities” con información de los 10 amenities
que aparecen con más frecuencia. El resultado debe mostrar el amenity y la
cantidad de veces que aparece cada amenity. */

db.createView("top10_most_common_amenities", "listingsAndReviews", [
  {
    $unwind: "$amenities"
  },
  {
    $group: {
      _id: "$amenities",
      frecuency: { $sum: 1 }
    }
  },
  {
    $sort: { frecuency: -1 }
  },
  {
    $limit: 10
  }
]);

db.top10_most_common_amenities.find();

/* 4.​ Actualizar los alojamientos de Brazil que tengan un rating global
(“review_scores.review_scores_rating”)
asignado,
agregando
el
campo
"quality_label" que clasifique el alojamiento como “High” (si el rating global es mayor
o igual a 90), “Medium” (si el rating global es mayor o igual a 70), “Low” (valor por
defecto) calidad..
HINTS: (i) para actualizar se puede usar pipeline de agregación. (ii) El operador
$cond o $switch pueden ser de utilidad. */

db.listingsAndReviews.updateMany(
  {
    "address.country": "Brazil",
    "review_scores.review_scores_rating": { $not: { $eq: null } }
  },
  [
    {
      $set: {
        quality_label: {
          $switch: {
            branches: [
              {
                case: { $gte: ["$review_scores.review_scores_rating", 90] },
                then: "High"
              },
              {
                case: { $gte: ["$review_scores.review_scores_rating", 70] },
                then: "Medium"
              }
            ],
            default: "Low"
          }
        }
      }
    }
  ]
);

/* 5.​ (a) Especificar reglas de validación en la colección listingsAndReviews a los
siguientes campos requeridos: name, address, amenities, review_scores, and
reviews ( y todos sus campos anidados). Inferir los tipos y otras restricciones que
considere adecuados para especificar las reglas a partir de los documentos de la
colección.
(b) Testear la regla de validación generando dos casos de fallas en la regla de
validación y un caso de éxito en la regla de validación. Aclarar en la entrega cuales
son los casos y por qué fallan y cuales cumplen la regla de validación. Los casos no
deben ser triviales, es decir los ejemplos deben contener todos los campos
especificados en la regla. */

// a)

db.runCommand({
  collMod: "listingsAndReviews",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["name", "address", "amenities", "review_scores", "reviews"],
      properties: {
        name: { bsonType: "string" },
        address: {
          bsonType: "object",
          required: [
            "street",
            "suburb",
            "government_area",
            "market",
            "country",
            "country_code",
            "location"
          ],
          properties: {
            street: { bsonType: "string" },
            suburb: { bsonType: "string" },
            government_area: { bsonType: "string" },
            market: { bsonType: "string" },
            country: { bsonType: "string" },
            country_code: { bsonType: "string" },
            location: { bsonType: "object" }
          }
        },
        amenities: {
          bsonType: ["array"],
          minItems: 1,
          items: {
            bsonType: ["string"]
          }
        },
        review_scores: {
          bsonType: "object",
          required: [
            "review_scores_accuracy",
            "review_scores_cleanliness",
            "review_scores_checkin",
            "review_scores_communication",
            "review_scores_location",
            "review_scores_value",
            "review_scores_rating"
          ],
          properties: {
            review_scores_accuracy: { bsonType: "int" },
            review_scores_cleanliness: { bsonType: "int" },
            review_scores_checkin: { bsonType: "int" },
            review_scores_communication: { bsonType: "int" },
            review_scores_location: { bsonType: "int" },
            review_scores_value: { bsonType: "int" },
            review_scores_rating: { bsonType: "int" }
          }
        },
        reviews: {
          bsonType: ["array"],
          minItems: 1,
          items: {
            bsonType: ["object"]
          }
        }
      }
    }
  },
  validationAction: "error"
});

// b)
// Éxito
db.listingsAndReviews.insertOne({
  _id: 15999999321211,
  name: "Club Fiesta",
  address: {
    street: "Av. illia",
    suburb: "",
    government_area: "Algo",
    market: "Algo",
    country: "Argentina",
    country_code: "ARG",
    location: {}
  },
  amenities: ["TV", "Comida"],
  review_scores: {
    review_scores_accuracy: 2,
    review_scores_cleanliness: 5,
    review_scores_checkin: 7,
    review_scores_communication: 8,
    review_scores_location: 9,
    review_scores_value: 1,
    review_scores_rating: 10
  },
  reviews: [{}]
});

// Fallo 1

db.listingsAndReviews.insertOne({
  _id: 15999999933217398127,
  name: "Club Fiesta",
  address: {
    street: "Av. illia",
    suburb: "",
    government_area: "Algo",
    market: "Algo",
    country: "Argentina",
    country_code: "ARG",
    location: "" // Falla y no inserta porque este campo debería ser un objeto
  },
  amenities: ["TV", "Comida"],
  review_scores: {
    review_scores_accuracy: 2,
    review_scores_cleanliness: 5,
    review_scores_checkin: 7,
    review_scores_communication: 8,
    review_scores_location: 9,
    review_scores_value: 1,
    review_scores_rating: 10
  },
  reviews: [{}]
});

// Fallo 2

db.listingsAndReviews.insertOne({
  _id: 1599999998793213892131,
  name: "Club Fiesta",
  address: {
    street: "Av. illia",
    suburb: "",
    government_area: "Algo",
    // market: "Algo", // me tira error porque me falta este campo que es requerido
    country: "Argentina",
    country_code: "ARG",
    location: {}
  },
  amenities: ["TV", "Comida"],
  review_scores: {
    review_scores_accuracy: "hola", // me tira error porque este campo debe ser de tipo entero
    review_scores_cleanliness: 5,
    review_scores_checkin: 7,
    review_scores_communication: 8,
    review_scores_location: 9,
    review_scores_value: 1,
    review_scores_rating: 10
  },
  reviews: [{}]
});
