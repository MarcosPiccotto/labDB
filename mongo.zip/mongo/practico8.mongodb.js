// Create a new database.
// sudo docker start mongo-labs2
//  mongosh --host 172.17.0.2
db.theaters.aggregate([
  {
    $group: {
      _id: "$location.address.state",
      count: { $sum: 1 }
    }
  }
]);

// Cantidad de estados con al menos dos cines (theaters) registrados

db.theaters.aggregate([
  {
    $group: {
      _id: "$location.address.state",
      count: { $sum: 1 }
    }
  },
  {
    $match: {
      count: { $gte: 2 }
    }
  },
  {
    $count: "states_two_theaters"
  }
]);

// Cantidad de películas dirigidas por "Louis Lumière". Se puede responder
// sin pipeline de agregación, realizar ambas queries.

db.movies.aggregate([
  {
    $match: {
      directors: { $in: ["Louis Lumière"] }
    }
  },
  {
    $count: "film_with_louis"
  }
]);

db.movies.find({ directors: "Louis Lumière" }).count();

// Cantidad de películas estrenadas en los años 50 (desde 1950 hasta 1959).
// Se puede responder sin pipeline de agregación, realizar ambas queries.

db.movies.aggregate([
  {
    $match: {
      year: { $gte: 1950, $lte: 1959 }
    }
  },
  {
    $count: "films50s"
  }
]);

db.movie.find({ year: { $gte: 1950, $lte: 1959 } }).count();

// Listar los 10 géneros con mayor cantidad de películas (tener en cuenta que
// las películas pueden tener más de un género). Devolver el género y la cantidad
// de películas. Hint: unwind puede ser de utilidad

db.movies.aggregate([
  {
    $unwind: "$genres"
  },
  {
    $group: {
      _id: "$genres",
      count: { $sum: 1 }
    }
  },
  {
    $sort: { count: -1 }
  },
  {
    $limit: 10
  }
]);

// Top 10 de usuarios con mayor cantidad de comentarios, mostrando Nombre,
// Email y Cantidad de Comentarios.

db.comments.aggregate([
  {
    $group: {
      _id: { email: "$email", name: "$name" },
      countCM: { $sum: 1 }
    }
  },
  {
    $project: {
      _id: 0,
      countCM: 1,
      email: "$_id.email",
      name: "$_id.name"
    }
  },
  {
    $sort: { countCM: -1 }
  },
  { $limit: 10 }
]);

// 7) Ratings de IMDB promedio, mínimo y máximo por año de las películas estrenadas
// en los años 80 (desde 1980 hasta 1989), ordenados de mayor a menor por promedio del año.

db.movies.aggregate([
  {
    $match: {
      year: { $gte: 1980, $lte: 1989 },
      "imdb.rating": { $not: { $eq: "" } }
    }
  },
  {
    $group: {
      _id: "$year",
      avg: { $avg: "$imdb.rating" },
      min: { $min: "$imdb.rating" },
      max: { $max: "$imdb.rating" }
    }
  },
  { $sort: { avg: -1 } }
]);

// 8) Título, año y cantidad de comentarios de las 10 películas con más comentarios.

db.movies.aggregate([
  {
    $lookup: {
      from: "comments",
      localField: "_id",
      foreignField: "movie_id",
      as: "comments_film"
    }
  },
  {
    $addFields: {
      q_comments: { $size: "$comments_film" }
    }
  },
  {
    $project: {
      _id: 0,
      title: 1,
      year: 1,
      q_comments: 1
    }
  },
  {
    $sort: {
      q_comments: -1
    }
  },
  {
    $limit: 10
  }
]);
// HACER LA FORMA DE COMMENTS A MOVIE

// 9) Crear una vista con los 5 géneros con mayor cantidad de comentarios,
// junto con la cantidad de comentarios.

db.comments.aggregate([
  {
    $group: {
      _id: "$movie_id",
      count: { $sum: 1 }
    }
  },
  {
    $lookup: {
      from: "movies",
      localField: "_id",
      foreignField: "_id",
      as: "movie_genre"
    }
  },
  {
    $unwind: "$movie_genre"
  },
  {
    $unwind: "$movie_genre.genres"
  },
  {
    $group: {
      _id: "$movie_genre.genres",
      count_comments: { $sum: "$count" }
    }
  },
  {
    $sort: { count_comments: -1 }
  },
  { $limit: 5 }
]);

db.createView("top_5_genres_comments", "comments", [
  {
    $group: {
      _id: "$movie_id",
      count: { $sum: 1 }
    }
  },
  {
    $lookup: {
      from: "movies",
      localField: "_id",
      foreignField: "_id",
      as: "movie_genre"
    }
  },
  {
    $unwind: "$movie_genre"
  },
  {
    $unwind: "$movie_genre.genres"
  },
  {
    $group: {
      _id: "$movie_genre.genres",
      count_comments: { $sum: "$count" }
    }
  },
  {
    $sort: { count_comments: -1 }
  },
  { $limit: 5 }
]);

db.top_5_genres_comments.findOne();

/* 10) Listar los actores (cast) que trabajaron en 2 o más películas dirigidas 
por "Jules Bass". Devolver el nombre de estos actores junto con la lista de películas 
(solo título y año) dirigidas por “Jules Bass” en las que trabajaron. 
Hint1: addToSet
Hint2: {'name.2': {$exists: true}} permite filtrar arrays con al menos 2 elementos, entender por qué.
Hint3: Puede que tu solución no use Hint1 ni Hint2 e igualmente sea correcta
*/

db.movies.aggregate([
  {
    $match: {
      directors: { $in: ["Jules Bass"] }
    }
  },
  {
    $unwind: "$cast"
  },
  {
    $group: {
      _id: "$cast",
      movies: { $addToSet: { title: "$title", year: "$year" } }
    }
  },
  {
    $match: { "movies.1": { $exists: true } }
  }
]);

// 11)
// Listar los usuarios que realizaron comentarios durante el mismo mes de lanzamiento
// de la película comentada, mostrando Nombre, Email, fecha del comentario, título
// de la película, fecha de lanzamiento. HINT: usar $lookup con multiple condiciones

db.comments.aggregate([
  {
    $lookup: {
      from: "movies",
      let: { com_id: "$movie_id", com_date: "$date" },
      pipeline: [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$_id", "$$com_id"] },
                {
                  $eq: [
                    {
                      $dateToString: {
                        format: "%Y-%m",
                        date: { $toDate: "$released" }
                      }
                    },
                    { $dateToString: { format: "%Y-%m", date: "$$com_date" } }
                  ]
                }
              ]
            }
          }
        }
      ],
      as: "movie_info"
    }
  },
  {
    $match: {
      "movie_info.0": { $exists: true }
    }
  },
  {
    $unwind: "$movie_info"
  },
  {
    $project: {
      _id: 0,
      name: "$name",
      email: "$email",
      date: "$date",
      title: "$movie_info.title",
      released: "$movie_info.released"
    }
  }
]);

// 12) Listar el id y nombre de los restaurantes junto con su puntuación máxima,
// mínima y la suma total. Se puede asumir que el restaurant_id es único.
//Resolver con $group y accumulators.
//Resolver con expresiones sobre arreglos (por ejemplo, $sum) pero sin $group.
//Resolver como en el punto b) pero usar $reduce para calcular la puntuación total.
//Resolver con find.

use("restaurantdb");
db.restaurants.aggregate([
  {
    $unwind: "$grades"
  },
  {
    $group: {
      _id: "$restaurant_id",
      max: { $max: "$grades.score" },
      min: { $min: "$grades.score" },
      sum: { $sum: "$grades.score" }
    }
  }
]);
// ---
db.restaurants.aggregate([
  {
    $project: {
      _id: 0,
      name: 1,
      sum: {
        $reduce: {
          input: "$grades",
          initialValue: 0,
          in: { $add: ["$$value", "$$this.score"] }
        }
      },
      min: {
        $reduce: {
          input: "$grades",
          initialValue: Infinity,
          // $$this.score <  $$value , value=$$this.score, sino, no hago nada
          in: {
            $cond: [
              { $lt: ["$$this.score", "$$value"] },
              "$$this.score",
              "$$value"
            ]
          }
        }
      },
      max: {
        $reduce: {
          input: "$grades",
          initialValue: -Infinity,
          // $$value > $$this.score, value=$$this.score, sino, no hago nada
          in: {
            $cond: [
              { $gt: ["$$this.score", "$$value"] },
              "$$this.score",
              "$$value"
            ]
          }
        }
      }
    }
  }
]);

// 13- Actualizar los datos de los restaurantes añadiendo dos campos nuevos.
// "average_score": con la puntuación promedio
// "grade": con "A" si "average_score" está entre 0 y 13,
//   con "B" si "average_score" está entre 14 y 27
//   con "C" si "average_score" es mayor o igual a 28
// Se debe actualizar con una sola query.
// HINT1. Se puede usar pipeline de agregación con la operación update
// HINT2. El operador $switch o $cond pueden ser de ayuda.
use("restaurants");
db.restaurants.updateMany(
  // filtro (todos los docs)
  {},
  [
    {
      $set: {
        average_score: { $avg: "$grades.score" }
      }
    },
    {
      $set: {
        grade: {
          $switch: {
            branches: [
              {
                case: { $eq: ["$average_score", null] },
                then: "N/A"
              },
              {
                case: { $gte: ["$average_score", 28] },
                then: "C"
              },
              {
                case: { $gte: ["$average_score", 14] },
                then: "B"
              },
              {
                case: { $gte: ["$average_score", 0] },
                then: "A"
              }
            ],
            default: "N/A"
          }
        }
      }
    }
  ]
);
