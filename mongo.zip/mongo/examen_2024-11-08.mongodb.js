/* 
   1. Buscar los documentos donde el alumno tiene:
   (i) un puntaje mayor o igual a 80 en "exam" o bien un puntaje mayor o igual a 90 en
   "quiz" y
   (ii) un puntaje mayor o igual a 60 en todos los "homework" (en otras palabras no
   tiene un puntaje menor a 60 en algún "homework")
   Las dos condiciones se tienen que cumplir juntas (es un AND)
   Se debe mostrar todos los campos excepto el _id, ordenados por el id de la clase y
   id del alumno en orden descendente y ascendente respectivamente. 
*/
use("university");
db.grades.find(
  {
    $and: [
      {
        "scores": {
          $elemMatch: {
            $or: [
              { type: "exam", score: { $gte: 80 } },
              { type: "quiz", score: { $gte: 90 } }
            ]
          }
        }
      },
      {
        "scores": {
          $not: {
            $elemMatch: { type: "homework", score: { $lt: 60 } }
          }
        }
      }
    ]
  },
  {
    _id: 0
  }
).sort({ class_id: -1, student_id: 1 }).count()


/* 
   2. Calcular el puntaje mínimo, promedio, y máximo que obtuvo el alumno en las clases
   20, 220, 420. El resultado debe mostrar además el id de la clase y el id del alumno,
   ordenados por alumno y clase en orden ascendentes. 
*/
use("university");
db.grades.aggregate([
  {
    $match: {
      class_id: { $in: [20, 220, 420] }
    }
  },
  {
    $unwind: "$scores"
  },
  {
    $group: {
      _id: { class_id: "$class_id", student_id: "$student_id" },
      min: { $min: "$scores.score" },
      max: { $max: "$scores.score" },
      avg: { $avg: "$scores.score" }
    }
  },
  {
    $sort: {
        "_id.student_id": 1,
        "_id.class_id": 1
    }
  },
  {
    $project: {
      _id: 0,
      class_id: "$_id.class_id",
      student_id: "$_id.student_id",
      min: 1,
      avg: 1,
      max: 1
    }
  }
])

/* 
   3. Para cada clase listar el puntaje máximo de las evaluaciones de tipo "exam" y el
   puntaje máximo de las evaluaciones de tipo "quiz". Listar en orden ascendente por el
   id de la clase. HINT: El operador $filter puede ser de utilidad. 
*/
use("university");
db.grades.aggregate([
  {
    $unwind: "$scores"
  },
  {
    $group: {
      _id: "$class_id",
      max_exam: { $max: { $cond: [{ $eq: ["$scores.type", "exam"] }, "$scores.score", null] } },
      max_quiz: { $max: { $cond: [{ $eq: ["$scores.type", "quiz"] }, "$scores.score", null] } }
    }
  },
  {
    $sort: {
      _id: 1
    }
  }
])

use("university");
db.grades.aggregate([
  {
    $project: {
      _id: 0,
      class_id: 1,
      exam_scores: {
        $filter: {
          input: "$scores",
          as: "s",
          cond: { $eq: ["$$s.type", "exam"] }
        }
      },
      quiz_scores: {
        $filter: {
          input: "$scores",
          as: "s",
          cond: { $eq: ["$$s.type", "quiz"] }
        }
      }
    }
  },
  
  {
    $project: {
      class_id: 1,
      max_exam_doc: { $max: "$exam_scores.score" },
      max_quiz_doc: { $max: "$quiz_scores.score" }
    }
  },

  {
    $group: {
      _id: "$class_id",
      max_exam: { $max: "$max_exam_doc" },
      max_quiz: { $max: "$max_quiz_doc" }
    }
  },
  
  // 4. Ordenar
  {
    $sort: {
      _id: 1
    }
  }
])

/* 
   4. Crear una vista "top10students" que liste los 10 estudiantes con los mejores
   promedios. 
*/
use("university");
// db.top10students.find();
db.createView(
    "top10students",
    "grades",
    [
      {
        $unwind: "$scores"
      },
      {
        $group: {
          _id: "$student_id",
          avg: { $avg: "$scores.score" }
        }
      },
      {
        $sort: {
          avg: -1
        }
      },
      {
        $limit: 10
      }
    ]
);

/* 
   5. Actualizar los documentos de la clase 339, agregando dos nuevos campos: el
   campo "score_avg" que almacena el puntaje promedio y el campo "letter" que tiene
   el valor "NA" si el puntaje promedio está entre [0, 60), el valor "A" si el puntaje
   promedio está entre [60, 80) y el valor "P" si el puntaje promedio está entre [80, 100].
   HINTS: (i) para actualizar se puede usar pipeline de agregación. (ii) El operador
   $cond o $switch pueden ser de utilidad. 
*/
use("university");
db.grades.updateMany(
  { class_id: 339 },
  [
    {
      $set: {
        "score_avg": { $avg: "$scores.score" }
      }
    },
    {
      $set: {
        "letter": {
          $switch: {
            branches: [
              { case: { $lt: [ "$score_avg", 60 ] }, then: "NA" },
              { case: { $lt: [ "$score_avg", 80 ] }, then: "A" },
              { case: { $lt: [ "$score_avg", 100 ] }, then: "P" }
            ],
            default: "N/A"
          }
        }
      }
    }
  ]
)

/* 
   6. (a) Especificar reglas de validación en la colección grades para todos sus campos y
   subdocumentos anidados. Inferir los tipos y otras restricciones que considere
   adecuados para especificar las reglas a partir de los documentos de la colección.
   (b) Testear la regla de validación generando dos casos de fallas en la regla de
   validación y un caso de éxito en la regla de validación. Aclarar en la entrega cuales
   son los casos y por qué fallan y cuales cumplen la regla de validación. Los casos no
   deben ser triviales, es decir los ejemplos deben contener todos los campos. 
*/
use("university");
db.runCommand(
    {
        collMod: "grades",
        validator: {
            $jsonSchema: {
                bsonType: "object",
                required: ["class_id", "student_id", "scores"],
                properties: {
                    class_id: {
                        bsonType: "int"
                    },
                    student_id: {
                        bsonType: "int"
                    },
                    scores: {
                        bsonType: "array",
                        minItems: 1,
                        items: {
                            bsonType: "object",
                            required: ["type", "score"],
                            properties: {
                                type: {
                                    enum: ["exam", "quiz", "homework"]
                                },
                                score: {
                                    bsonType: "double",
                                    minimum: 0,
                                    maximum: 100
                                }
                            }
                        }
                    },
                    score_avg: {
                        bsonType: "double"
                    },
                    letter: {
                        bsonType: "string"
                    }
                }
            }
        },
        validationLevel: "strict",
        validationAction: "error"
    }
)

// Caso de exito
use("university");
db.grades.insertOne(
    {
        student_id: 1000,
        class_id: 500,
        scores: [
            { type: "exam", score: 85.5 },
            { type: "quiz", score: 92.5 },
            { type: "homework", score: 70.5 }
        ]
    }
)

// Caso de fallo 1 (type incorrecto)
use("university");
db.grades.insertOne(
    {
        student_id: 1001,
        class_id: 501,
        scores: [
            { type: "exam", score: 85.5 },
            { type: "quiz", score: 92.5 },
            { type: "presentation", score: 70.5 }
        ]
    }
)

// Caso de fallo 2 (maximo superado)
use("university");
db.grades.insertOne(
    {
        student_id: 1002,
        class_id: 502,
        scores: [
            { type: "exam", score: 102.5 },
            { type: "homework", score: 0.5}
        ]
    }
)