// Create a new database.
// sudo docker start mongo-labs2
//  mongosh --host 172.17.0.2
use("mflix");

db.comments.findOne();

// db.users.insertMany([
//   { email: "juanperon@gmail.com", name: "Juan", password: "1234" },
//   { email: "1@gmail.com", name: "Evita", password: "1234" },
//   { email: "2@gmail.com", name: "Martin", password: "1234" },
//   { email: "3@gmail.com", name: "esperanza", password: "1234" },
//   { email: "4@gmail.com", name: "fe", password: "1234" },
//   { email: "5@gmail.com", name: "esteban", password: "1234" }
// ]);

// db.comments.find({}, { movie_id: 1 });

db.movies
  .find(
    {
      year: { $gte: 1990, $lte: 1999 },
      "imdb.rating": { $type: "double", $ne: "" }
    },
    { _id: 0, title: 1, year: 1, cast: 1, directors: 1, "imdb.rating": 1 }
  )
  .sort({ "imdb.rating": -1 })
  .limit(10);

// Listar el nombre, email, texto y fecha de los comentarios que la película
// con id (movie_id) ObjectId("573a1399f29313caabcee886") recibió
// entre los años 2014 y 2016 inclusive. Listar ordenados por fecha.
// Escribir una nueva consulta (modificando la anterior) para responder
// ¿Cuántos comentarios recibió?
db.comments
  .find(
    {
      movie_id: ObjectId("573a1399f29313caabcee886"),
      date: {
        $gte: new Date("2014-01-01"),
        $lte: new Date("2016-12-31")
      }
    },
    {
      _id: 0,
      name: 1,
      email: 1,
      text: 1,
      date: 1
    }
  )
  .sort({ year: -1 })
  .count();

db.comments.aggregate([
  {
    $match: {
      movie_id: ObjectId("573a1399f29313caabcee886"),
      date: {
        $gte: new Date("2014-01-01"),
        $lte: new Date("2016-12-31")
      }
    }
  },
  { $sort: { year: -1 } },
  { $count: "nums of commentaries" }
]);

// Listar el nombre, id de la película, texto y fecha de los 3 comentarios más
// recientes realizados por el usuario con email patricia_good@fakegmail.com.

db.comments
  .find(
    { email: "patricia_good@fakegmail.com" },
    {
      _id: 0,
      name: 1,
      movie_id: 1,
      text: 1,
      date: 1
    }
  )
  .sort({ date: -1 })
  .limit(3);

// Listar el título, idiomas (languages), géneros, fecha de lanzamiento (released)
//  y número de votos (“imdb.votes”) de las películas de géneros Drama y Action
// (la película puede tener otros géneros adicionales), que solo estánx disponibles
// en un único idioma y por último tengan un rating (“imdb.rating”) mayor a 9
// o bien tengan una duración (runtime) de al menos 180 minutos. Listar ordenados
//  por fecha de lanzamiento y número de votos.

db.movies
  .find(
    {
      genres: { $all: ["Drama", "Action"] },
      languages: { $size: 1 },
      $or: [{ "imdb.rating": { $gte: 9 } }, { runtime: { $gte: 180 } }]
    },
    {
      _id: 0,
      title: 1,
      languages: 1,
      genres: 1,
      released: 1,
      "imdb.votes": 1
    }
  )
  .sort({ released: -1, "imdb.votes": -1 });

// Listar el id del teatro (theaterId), estado (“location.address.state”),
// ciudad (“location.address.city”), y coordenadas (“location.geo.coordinates”)
// de los teatros que se encuentran en algunos de los estados "CA", "NY", "TX"
// y el nombre de la ciudades comienza con una ‘F’. Listar ordenados por estado y ciudad.
db.theaters
  .find(
    {
      "location.address.state": { $in: ["CA", "NA", "TX"] },
      "location.address.city": { $regex: "^F" }
    },
    {
      _id: 0,
      theaterId: 1,
      "location.address.state": 1,
      "location.address.city": 1,
      "location.address.coordinates": 1
    }
  )
  .sort({ "location.address.city": -1, "location.address.state": -1 });

// 7- Actualizar los valores de los campos texto (text) y fecha (date) del comentario
// cuyo id es ObjectId("5b72236520a3277c015b3b73") a "mi mejor comentario" y fecha actual respectivamente.
use("mflix");
// db.comments.find({_id: ObjectId("5b72236520a3277c015b3b73")})
db.comments.updateOne(
  {
    _id: ObjectId("5b72236520a3277c015b3b73")
  },
  {
    $set: {
      text: "mi mejor comentario",
      date: new Date()
    }
  }
);

// 8- Actualizar el valor de la contraseña del usuario cuyo email es joel.macdonel@fakegmail.com
// a "some password". La misma consulta debe poder insertar un nuevo usuario en caso que el usuario no exista.
// Ejecute la consulta dos veces. ¿Qué operación se realiza en cada caso?  (Hint: usar upserts).
use("mflix");
// db.users.find({email: "joel.macdonel@fakegmail.com"})
db.users.updateOne(
  {
    email: "joel.macdonel@fakegmail.com"
  },
  {
    $set: {
      password: "some password"
    }
  },
  {
    upsert: true
  }
);

// 9- Remover todos los comentarios realizados por el usuario cuyo email es victor_patel@fakegmail.com durante el año 1980.
use("mflix");
// db.comments.find(
//   {
//     email: "victor_patel@fakegmail.com",
//     date: {
//       $gte: new Date("1980-01-01"),
//       $lte: new Date("1980-12-31")
//     }
//   }
// ).count()

db.comments.deleteMany({
  email: "victor_patel@fakegmail.com",
  date: {
    $gte: new Date("1980-01-01"),
    $lte: new Date("1980-12-31")
  }
});
