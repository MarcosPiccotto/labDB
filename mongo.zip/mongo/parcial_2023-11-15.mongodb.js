/* 
    1. Buscar las ventas realizadas en "London", "Austin" o "San Diego"; a un customer con
    edad mayor-igual a 18 años que tengan productos que hayan salido al menos 1000
    y estén etiquetados (tags) como de tipo "school" o "kids" (pueden tener más
    etiquetas).
    Mostrar el id de la venta con el nombre "sale", la fecha (“saleDate"), el storeLocation,
    y11 el "email del cliente. No mostrar resultados anidados. 
*/

db.sales.find(
  {
    storeLocation: {
      $in: ["London", "Austin", "San Diego"]
    },
    "customer.age": {
      $gte: 18
    },

    items: {
      $elemMatch: {
        price: { $gte: 1000 }
      }
    }
  },
  {}
);

db.sales.aggregate([
  {
    $match: {
      storelocation: {
        in: ["London", "Austin", "San Diego"]
      }
    }
  }
]);

/* 
    2. Buscar las ventas de las tiendas localizadas en Seattle, donde el método de compra
    sea ‘In store’ o ‘Phone’ y se hayan realizado entre 1 de febrero de 2014 y 31 de enero
    de 2015 (ambas fechas inclusive). Listar el email y la satisfacción del cliente, y el
    monto total facturado, donde el monto de cada item se calcula como 'price *
    quantity'. Mostrar el resultado ordenados por satisfacción (descendente), frente a
    empate de satisfacción ordenar por email (alfabético). 
*/

/* 
    3. Crear la vista salesInvoiced que calcula el monto mínimo, monto máximo, monto
    total y monto promedio facturado por año y mes. Mostrar el resultado en orden
    cronológico. No se debe mostrar campos anidados en el resultado. 
*/

/* 
    4. Mostrar el storeLocation, la venta promedio de ese local, el objetivo a cumplir de
    ventas (dentro de la colección storeObjectives) y la diferencia entre el promedio y el
    objetivo de todos los locales. 
*/

/* 
    5. Especificar reglas de validación en la colección sales utilizando JSON Schema.
    a. Las reglas se deben aplicar sobre los campos: saleDate, storeLocation,
    purchaseMethod, y customer ( y todos sus campos anidados ). 
    Inferir lostipos y otras restricciones que considere adecuados para especificar las
    reglas a partir de los documentos de la colección.
    b. Para testear las reglas de validación crear un caso de falla en la regla de
    validación y un caso de éxito (Indicar si es caso de falla o éxito) 
*/
