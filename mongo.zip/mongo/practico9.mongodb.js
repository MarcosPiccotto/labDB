// Create a new database.
// sudo docker start mongo-labs2
//  mongosh --host 172.17.0.2

// Agregar las siguientes reglas de validación usando JSON Schema. Luego de cada especificación testear que efectivamente
// las reglas de validación funcionen, intentando insertar 5 documentos válidos y 5 inválidos (por distintos motivos).

// 1. Especificar en la colección users las siguientes reglas de validación: El campo name (requerido) debe ser un string
//    con un máximo de 30 caracteres, email (requerido) debe ser un string que matchee con la expresión regular: "^(.*)@(.*)\\.(.{2,4})$",
//    password (requerido) debe ser un string con al menos 50 caracteres.
use("mflix");
db.runCommand({
  collMod: "users",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["name", "email", "password"],
      properties: {
        name: { bsonType: "string", maxLength: 30 },
        email: { bsonType: "string", pattern: "^(.*)@(.*)\\.(.{2,4})$" },
        password: { bsonType: "string", minLength: 50 }
      }
    }
  }
});

// 2. Obtener metadata de la colección users que garantice que las reglas de validación fueron correctamente aplicadas.
use("mflix");
db.getCollectionInfos({ name: "users" });

// 3. Especificar en la colección theaters las siguientes reglas de validación: El campo theaterId (requerido) debe ser un int
//    y location (requerido) debe ser un object con:
//    un campo address (requerido) que sea un object con campos street1, city, state y zipcode todos de tipo string y requeridos
//    un campo geo (no requerido) que sea un object con un campo type, con valores posibles “Point” o null
//    y coordinates que debe ser una lista de 2 doubles
//    Por último, estas reglas de validación no deben prohibir la inserción o actualización de documentos
//    que no las cumplan sino que solamente deben advertir.
use("mflix");
db.runCommand({
  collMod: "theaters",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["theaterId", "location"],
      properties: {
        theaterId: { bsonType: "int" },
        location: {
          bsonType: "object",
          required: ["address"],
          properties: {
            address: {
              bsonType: "object",
              required: ["street1", "city", "state", "zipcode"],
              properties: {
                street1: { bsonType: "string" },
                city: { bsonType: "string" },
                state: { bsonType: "string" },
                zipcode: { bsonType: "string" }
              }
            },
            geo: {
              bsonType: "object",
              properties: {
                type: {
                  bsonType: ["string", "null"],
                  enum: ["Point", null]
                },
                coordinates: {
                  bsonType: "array",
                  minItems: 2,
                  maxItems: 2,
                  items: { bsonType: "double" }
                }
              }
            }
          }
        }
      }
    }
  },
  validationAction: "warn"
});

// 4. Especificar en la colección movies las siguientes reglas de validación: El campo title (requerido) es de tipo string,
//    year (requerido) int con mínimo en 1900 y máximo en 3000, y que tanto cast, directors, countries,
//    como genres sean arrays de strings sin duplicados.
//    Hint: Usar el constructor NumberInt() para especificar valores enteros a la hora de insertar documentos. Recordar que mongo shell
//    es un intérprete javascript y en javascript los literales numéricos son de tipo Number (double).
use("mflix");
db.runCommand({
  collMod: "movies",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["title", "year", "cast", "directors", "countries", "genres"],
      properties: {
        title: { bsonType: "string" },
        year: { bsonType: "int", minimum: 1900, maximum: 3000 },
        cast: {
          bsonType: "array",
          uniqueItems: true,
          items: { bsonType: "string" }
        },
        directors: {
          bsonType: "array",
          uniqueItems: true,
          items: { bsonType: "string" }
        },
        countries: {
          bsonType: "array",
          uniqueItems: true,
          items: { bsonType: "string" }
        },
        genres: {
          bsonType: "array",
          uniqueItems: true,
          items: { bsonType: "string" }
        }
      }
    }
  }
});

// 5. Crear una colección userProfiles con las siguientes reglas de validación: Tenga un campo user_id (requerido) de tipo “objectId”,
//    un campo language (requerido) con alguno de los siguientes valores [ “English”, “Spanish”, “Portuguese” ]
//    y un campo favorite_genres (no requerido) que sea un array de strings sin duplicados.
use("mflix");
db.createCollection("userProfiles", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["user_id", "language"],
      properties: {
        user_id: { bsonType: "objectId" },
        language: {
          bsonType: "string",
          enum: ["English", "Spanish", "Portuguese"]
        },
        favorite_genres: {
          bsonType: "array",
          uniqueItems: true,
          items: { bsonType: "string" }
        }
      }
    }
  }
});

// 6. Revisar analisis_mod_datos.md

// 7. Dado el diagrama de la base de datos shop junto con las queries más importantes.

// Queries
// 1. Listar el id, titulo, y precio de los libros y sus categorías de un autor en particular
// 2. Cantidad de libros por categorías
// 3. Listar el nombre y dirección entrega y el monto total (quantity * price) de sus pedidos para un order_id dado.

// Debe crear el modelo de datos en mongodb aplicando las estrategias “Modelo de datos anidados” y Referencias.
// El modelo de datos debe permitir responder las queries de manera eficiente.
// Inserte algunos documentos para las colecciones del modelo de datos.
// Opcionalmente puede especificar una regla de validación de esquemas para las colecciones.
use("mi_base");
db.books.insertOne({
  book_id: 1234,
  title: "Prueba1",
  author_id: "AutorPrueba",
  price: 10.99,
  category: {
    category_id: "1",
    name: "CategoriaPrueba"
  }
});

use("mi_base");
db.orders.insertOne({
  order_id: 1000,
  delivery_info: {
    name: "Prueba",
    address: "Calle Prueba"
  },
  payment_info: {
    cc_name: "Juan perez",
    cc_number: "1234-1234-1234-1234",
    cc_expiry: "2021-01-01"
  },
  items: [
    {
      book_id: 1234,
      title: "Prueba1",
      price: 10.99,
      quantity: 1
    },
    {
      book_id: 1235,
      title: "Prueba2",
      price: 10.99,
      quantity: 1
    }
  ],
  total_amount: 21.98
});

// Q1: Libros y categorías de un autor
use("mi_base");
db.books.find(
  { author: "Jorge Luis Borges" },
  { _id: 0, book_id: 1, title: 1, price: 1, "category.name": 1 }
);

// Q2: Cantidad de libros por categorías
use("mi_base");
db.books.aggregate([
  {
    $group: {
      _id: "$category.name",
      count: { $sum: 1 }
    }
  }
]);

// Q3: Total de un pedido (order_id)
use("mi_base");
db.orders.aggregate([
  {
    $match: { order_id: 1001 }
  },
  {
    $project: {
      _id: 0,
      delivery_name: "$delivery_info.name",
      delivery_address: "$delivery_info.address",
      monto_total: {
        $sum: {
          // $multiply toma los campos del array 'items'
          $map: {
            input: "$items",
            as: "item",
            in: { $multiply: ["$$item.quantity", "$$item.price"] }
          }
        }
      }
    }
  }
]);

use("mi_base");
db.runCommand({
  collMod: "books",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["book_id", "title", "author", "price", "category"],
      properties: {
        title: { bsonType: "string", description: "Debe ser un string" },
        price: {
          bsonType: "double",
          minimum: 0,
          description: "Debe ser un double positivo"
        },
        category: {
          bsonType: "object",
          required: ["name"],
          properties: {
            name: { bsonType: "string" }
          }
        }
      }
    }
  }
});

use("mi_base");
db.runCommand({
  collMod: "orders",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["delivery_info", "payment_info", "created_at", "items"],
      properties: {
        delivery_info: { bsonType: "object" },
        items: {
          bsonType: "array",
          minItems: 1, // Una orden no puede estar vacía
          items: {
            bsonType: "object",
            required: ["book_id", "title", "price", "quantity"],
            properties: {
              book_id: {
                bsonType: "objectId",
                description: "Referencia a `books`"
              },
              price: { bsonType: "double" },
              quantity: { bsonType: "int", minimum: 1 }
            }
          }
        }
      }
    }
  }
});

// El 8 es mas de lo mismo
