use("myDB");

db.createCollection("employees");
db.employees.insertOne({ user_id: "jmore", name: "Joe Moore", age: 22 });
