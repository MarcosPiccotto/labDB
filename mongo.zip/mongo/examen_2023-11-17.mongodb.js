use("supplies");
/* 
    1. Buscar las ventas realizadas en "London", "Austin" o "San Diego"; a un customer con
    edad mayor-igual a 18 años que tengan productos que hayan salido al menos 1000
    y estén etiquetados (tags) como de tipo "school" o "kids" (pueden tener más
    etiquetas).
    Mostrar el id de la venta con el nombre "sale", la fecha (“saleDate"), el storeLocation,
    y el "email del cliente. No mostrar resultados anidados. 
*/
db.sales.find(
    {
        storeLocation: {
            $in: ["London", "Austin", "San Diego"]
        },
        "customer.age": {
            $gte: 18
        },
        items: {
            $elemMatch: {
                "price": { $gte: 1000 },
                "tags": { $in: ["school", "kids"] }
            }
        }
    },
    {
        _id: 0,
        sale: "$_id",
        saleDate: "$saleDate",
        storeLocation: "$storeLocation",
        email: "$customer.email"
    }
);

/* 
    2. Buscar las ventas de las tiendas localizadas en Seattle, donde el método de compra
    sea ‘In store’ o ‘Phone’ y se hayan realizado entre 1 de febrero de 2014 y 31 de enero
    de 2015 (ambas fechas inclusive). Listar el email y la satisfacción del cliente, y el
    monto total facturado, donde el monto de cada item se calcula como 'price *
    quantity'. Mostrar el resultado ordenados por satisfacción (descendente), frente a
    empate de satisfacción ordenar por email (alfabético). 
*/
db.sales.aggregate([
  // --- Etapa 1: Filtrar los documentos ($match) ---
  {
    $match: {
      "storeLocation": "Seattle",
      "purchaseMethod": { $in: ["In Store", "Phone"] },
      "saleDate": {
        $gte: ISODate("2014-02-01T00:00:00Z"),
        $lte: ISODate("2015-01-31T23:59:59.999Z") 
      }
    }
  },
  
  // --- Etapa 2: Calcular el monto total ($addFields) ---
  {
    $addFields: {
      "montoTotal": {
        $sum: {
          $map: { // Multiplica price * quantity por cada item
            input: "$items",
            as: "item",
            in: { $multiply: [ "$$item.price", "$$item.quantity" ] }
          }
        }
      }
    }
  },

  // --- Etapa 3: Ordenar los resultados ($sort) ---
  {
    $sort: {
      "customer.satisfaction": -1, // -1 para descendente
      "customer.email": 1         //  1 para ascendente (alfabético)
    }
  },

  // --- Etapa 4: Formatear la salida final ($project) ---
  {
    $project: {
      _id: 0,
      email: "$customer.email",
      satisfaction: "$customer.satisfaction",
      montoTotal: "$montoTotal"
    }
  }
]);

/* 
    3. Crear la vista salesInvoiced que calcula el monto mínimo, monto máximo, monto
    total y monto promedio facturado por año y mes. Mostrar el resultado en orden
    cronológico. No se debe mostrar campos anidados en el resultado. 
*/
db.createView(
   "salesInvoiced",  // Nombre de la vista a crear
   "sales",          // Colección de origen
   [                 // Pipeline de agregación
    
    // Etapa 1: Pre-cálculo. 
    // Calcular el monto total de CADA venta y extraer año/mes.
    {
      $project: {
         _id: 0,
         year: { $year: "$saleDate" },
         month: { $month: "$saleDate" },
         // Calcula (precio * cantidad) para cada item y los suma
         totalSaleAmount: {
           $sum: {
             $map: {
               input: "$items",
               as: "item",
               in: { $multiply: [ "$$item.price", "$$item.quantity" ] }
             }
           }
         }
      }
    },
    
    // Etapa 2: Agrupación.
    // Agrupar por año y mes, y calcular las estadísticas.
    {
      $group: {
         _id: { "year": "$year", "month": "$month" }, // Clave de agrupación
         montoMinimo: { $min: "$totalSaleAmount" },
         montoMaximo: { $max: "$totalSaleAmount" },
         montoTotal: { $sum: "$totalSaleAmount" },
         montoPromedio: { $avg: "$totalSaleAmount" }
      }
    },
    
    // Etapa 3: Ordenamiento.
    // Ordenar por la clave de agrupación (cronológico).
    {
      $sort: {
         "_id.year": 1,   // 1 = ascendente
         "_id.month": 1
      }
    },
    
    // Etapa 4: Proyección final (Limpieza).
    // Aplanar la salida para que no haya campos anidados (como _id.year).
    {
      $project: {
        _id: 0,
        year: "$_id.year",
        month: "$_id.month",
        montoMinimo: "$montoMinimo",
        montoMaximo: "$montoMaximo",
        montoTotal: "$montoTotal",
        montoPromedio: "$montoPromedio"
      }
    }
   ]
);

/* 
    4. Mostrar el storeLocation, la venta promedio de ese local, el objetivo a cumplir de
    ventas (dentro de la colección storeObjectives) y la diferencia entre el promedio y el
    objetivo de todos los locales. 
*/
db.sales.aggregate([
  // Etapa 1: Calcular el monto total (price * quantity) para CADA venta
  {
    $addFields: {
      "totalSaleAmount": {
        $sum: {
          $map: {
            input: "$items",
            as: "item",
            in: { $multiply: [ "$$item.price", "$$item.quantity" ] }
          }
        }
      }
    }
  },
  
  // Etapa 2: Agrupar por storeLocation y calcular el promedio de esos montos
  {
    $group: {
      _id: "$storeLocation", // Agrupamos por tienda
      ventaPromedio: { $avg: "$totalSaleAmount" }
    }
  },
  
  // Etapa 3: Unir ($lookup) con la colección storeObjectives
  {
    $lookup: {
      from: "storeObjectives",      // La colección con la que queremos unir
      localField: "_id",            // El campo de esta pipeline (que es storeLocation)
      foreignField: "storeLocation",  // El campo en la colección storeObjectives
      as: "objetivoData"          // Nombre del nuevo array que contendrá la info
    }
  },
  
  // Etapa 4: Desanidar el resultado de $lookup
  // $lookup devuelve un array, lo "aplanamos" para acceder a sus campos.
  {
    $unwind: {
        path: "$objetivoData",
        preserveNullAndEmptyArrays: true
    }
  },
  
  // Etapa 5: Formatear la salida final y calcular la diferencia
  {
    $project: {
      _id: 0, // Ocultamos el _id
      storeLocation: "$_id", // Renombramos _id a storeLocation
      ventaPromedio: "$ventaPromedio",
      objetivo: "$objetivoData.objective", // Extraemos el valor del objetivo
      diferencia: {
        $subtract: [ "$ventaPromedio", "$objetivoData.objective" ]
      }
    }
  }
]);

/* 
    5. Especificar reglas de validación en la colección sales utilizando JSON Schema.
    a. Las reglas se deben aplicar sobre los campos: saleDate, storeLocation,
    purchaseMethod, y customer ( y todos sus campos anidados ). 
    Inferir lostipos y otras restricciones que considere adecuados para especificar las
    reglas a partir de los documentos de la colección.
    b. Para testear las reglas de validación crear un caso de falla en la regla de
    validación y un caso de éxito (Indicar si es caso de falla o éxito) 
*/
use("supplies")